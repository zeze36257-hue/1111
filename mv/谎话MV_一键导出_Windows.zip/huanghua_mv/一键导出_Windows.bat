@echo off
chcp 65001 >nul
cd /d "%~dp0"
rem Bundled Node.js + FFmpeg live in runtime\ ; nothing needs to be installed.
rem First run: unpack runtime_node.zip / runtime_ffmpeg.zip found here or in the parent folder.
for %%Z in (runtime_node.zip runtime_ffmpeg.zip) do (
  if exist "%~dp0%%Z" (
    echo Unpacking %%Z ...
    tar -xf "%~dp0%%Z" -C "%~dp0"
  ) else if exist "%~dp0..\%%Z" (
    echo Unpacking %%Z ...
    tar -xf "%~dp0..\%%Z" -C "%~dp0"
  )
)
if not exist "%~dp0runtime\node.exe" goto missing
if not exist "%~dp0runtime\ffmpeg.exe" goto missing
set "PATH=%~dp0runtime;%PATH%"
"%~dp0runtime\node.exe" run.mjs
exit /b %errorlevel%

:missing
echo.
echo runtime\node.exe or runtime\ffmpeg.exe is missing.
echo Put runtime_node.zip and runtime_ffmpeg.zip next to this .bat file
echo (or in the folder above it), then double-click this file again.
pause
exit /b 1
