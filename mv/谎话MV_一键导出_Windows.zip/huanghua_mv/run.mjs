// 一键导出：检查 FFmpeg / 浏览器 → 选画质 → 调用 mv/export.mjs → 成品放到「导出/」文件夹
// 由「一键导出_Windows.bat」或「一键导出_Mac.command」启动，也可以直接 node run.mjs
import { spawn, spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, readdirSync } from 'node:fs';
import { availableParallelism, homedir, platform } from 'node:os';
import { delimiter, dirname, join } from 'node:path';
import { createInterface } from 'node:readline/promises';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const MV = join(here, 'mv');
const OUT_DIR = join(here, '导出');
const WIN = platform() === 'win32', MAC = platform() === 'darwin';
const rl = createInterface({ input: process.stdin, output: process.stdout });
const ask = q => rl.question(q);
const quit = async (code, msg) => { if (msg) console.log('\n' + msg); await ask('\n按回车键关闭窗口…'); process.exit(code); };

console.log('==============================');
console.log('  《谎话》MV 一键导出');
console.log('==============================\n');

// ---- Node 版本 ----
if (+process.versions.node.split('.')[0] < 22) await quit(1, `Node.js 版本太旧（${process.version}），需要 22 以上：https://nodejs.org 下载 LTS 版安装后再运行。`);

// ---- FFmpeg ----
const has = cmd => spawnSync(cmd, ['-version'], { stdio: 'ignore', shell: WIN }).status === 0;
process.env.PATH = join(here, 'runtime') + delimiter + process.env.PATH;   // 包里自带的 ffmpeg.exe / node.exe 优先
if (WIN) process.env.PATH = join(process.env.LOCALAPPDATA || '', 'Microsoft', 'WinGet', 'Links') + delimiter + process.env.PATH;
if (MAC) process.env.PATH = ['/opt/homebrew/bin', '/usr/local/bin', process.env.PATH].join(delimiter);
if (!has('ffmpeg')) {
  console.log('没有找到 FFmpeg，正在自动安装…');
  if (WIN) spawnSync('winget', ['install', '-e', '--id', 'Gyan.FFmpeg', '--accept-source-agreements', '--accept-package-agreements'], { stdio: 'inherit', shell: true });
  else if (MAC && has('brew')) spawnSync('brew', ['install', 'ffmpeg'], { stdio: 'inherit' });
  if (WIN && !has('ffmpeg')) {   // winget 装完 PATH 还没刷新：直接去安装目录找
    const pk = join(process.env.LOCALAPPDATA || '', 'Microsoft', 'WinGet', 'Packages');
    for (const d of existsSync(pk) ? readdirSync(pk).filter(n => n.startsWith('Gyan.FFmpeg')) : [])
      for (const s of readdirSync(join(pk, d))) if (existsSync(join(pk, d, s, 'bin', 'ffmpeg.exe'))) process.env.PATH = join(pk, d, s, 'bin') + delimiter + process.env.PATH;
  }
  if (!has('ffmpeg')) await quit(1, WIN
    ? 'FFmpeg 自动安装失败。请手动安装：https://www.gyan.dev/ffmpeg/builds/ 下载后把 bin 文件夹加到 PATH，再运行一次。'
    : 'FFmpeg 自动安装失败。Mac 请先装 Homebrew（https://brew.sh），再运行：brew install ffmpeg');
}
console.log('✔ FFmpeg');

// ---- 浏览器（Chrome / Edge / Chromium）----
const L = process.env.LOCALAPPDATA || '', PF = process.env.PROGRAMFILES || 'C:/Program Files', PF86 = process.env['PROGRAMFILES(X86)'] || 'C:/Program Files (x86)';
const browser = [process.env.CHROME,
  join(PF, 'Google/Chrome/Application/chrome.exe'), join(PF86, 'Google/Chrome/Application/chrome.exe'), join(L, 'Google/Chrome/Application/chrome.exe'),
  join(PF86, 'Microsoft/Edge/Application/msedge.exe'), join(PF, 'Microsoft/Edge/Application/msedge.exe'),
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', join(homedir(), 'Applications/Google Chrome.app/Contents/MacOS/Google Chrome'),
  '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge', '/Applications/Chromium.app/Contents/MacOS/Chromium',
  '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', '/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/microsoft-edge',
].find(p => p && existsSync(p));
if (!browser) await quit(1, '没有找到 Chrome 或 Edge。请安装 Google Chrome（https://www.google.com/chrome）后再运行。');
process.env.CHROME = browser;
console.log('✔ 浏览器：' + browser);

// 完整音轨（原曲 + 片尾）：重新跑过 credits_audio.py 就用新的 .wav，否则用包里附带的无损 .flac
const audio = ['谎话_完整音轨.wav', '谎话_完整音轨.flac'].map(f => join(MV, 'output', f)).find(f => existsSync(f));
if (!audio) console.log('⚠ 没有 mv/output/谎话_完整音轨（.wav / .flac），片尾会没有声音（需要 Python：cd mv && python credits_audio.py）');

// ---- 选画质 ----
const presets = {
  1: { name: '30fps · 动态模糊3 · 最高画质', file: '谎话_MV_1080p30.mp4', args: ['--fps', '30', '--mb', '3', '--png', '--crf', '14', '--preset', 'slow'] },
  2: { name: '60fps · 动态模糊6 · 最高画质（最慢）', file: '谎话_MV_1080p60.mp4', args: ['--fps', '60', '--mb', '6', '--png', '--crf', '14', '--preset', 'slow'] },
  3: { name: '30fps · 动态模糊3 · 普通画质（较快）', file: '谎话_MV_1080p30_普通.mp4', args: ['--fps', '30', '--mb', '3'] },
  4: { name: '快速试看 · 30fps · 无动态模糊（最快，只看效果）', file: '谎话_MV_试看.mp4', args: ['--fps', '30', '--mb', '1', '--crf', '23', '--preset', 'veryfast'] },
};
console.log('\n请选择导出方式：');
for (const [k, p] of Object.entries(presets)) console.log(`  ${k}. ${p.name}`);
const pick = presets[(await ask('\n输入编号后按回车（直接回车 = 1）：')).trim() || '1'] || presets[1];

let range = [];
const part = (await ask('导出整首？直接回车 = 整首；只导出一段就输入「开始秒 结束秒」，例如 0 32.45：')).trim();
if (part) { const [a, b] = part.split(/[\s,，-]+/).map(Number); if (isFinite(a)) range.push('--from', String(a)); if (isFinite(b)) range.push('--to', String(b)); }

const cores = availableParallelism();
const workers = String(Math.max(1, Math.min(6, Math.floor(cores / 2))));
mkdirSync(OUT_DIR, { recursive: true });
const out = join(OUT_DIR, range.length ? pick.file.replace('.mp4', `_${part.replace(/[\s,，]+/g, '-')}s.mp4`) : pick.file);
console.log(`\n开始导出：${pick.name}，${workers} 个 worker → ${out}`);
console.log('（窗口里会显示进度；中途关掉窗口就会停止）\n');
rl.pause();

const t0 = Date.now();
const code = await new Promise(res => spawn(process.execPath, ['export.mjs', ...pick.args, ...range, ...(audio ? ['--audio', audio] : []), '--workers', workers, '--out', out], { cwd: MV, stdio: 'inherit' }).on('close', res));
rl.resume();
if (code !== 0) await quit(code || 1, '导出失败，请把上面的报错截图发给我。');
console.log(`\n✔ 完成，用时 ${Math.round((Date.now() - t0) / 60000)} 分钟：${out}`);
if (WIN) spawn('explorer', ['/select,', out], { detached: true, stdio: 'ignore' }).unref();
else if (MAC) spawn('open', ['-R', out], { detached: true, stdio: 'ignore' }).unref();
await quit(0);
